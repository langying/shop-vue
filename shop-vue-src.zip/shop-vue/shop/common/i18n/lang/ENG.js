export default {
  base: {
    test: 'test i18n',
    notFoundTips: '404'
  }
}

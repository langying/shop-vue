export default {
  base: {
    test: '测试i18n',
    notFoundTips: '404'
  }
}

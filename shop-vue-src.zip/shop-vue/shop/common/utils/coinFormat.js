function coinFormat(coinId){
    switch(coinId){
        case "1":
            return "HKD"
        bread;
        case "2":
            return "USD"
        bread;
        case "101":
            return "BTC"
        bread;
        case "102":
            return "LTC"
        bread;
        case "103":
            return "ETH"
        bread;
        case "104":
            return "PHI"
        bread;
        case "105":
            return "ACTC"
        bread;
    }
}
export default coinFormat;
var constant = {}
const BORROWUNIT = {"1":"天","2":"月","3":"年"}
const CONTACT = {
    "phone":"132 5207 4299",
    "qq":"259069142",
    "email":"259069142@qq.com",
    "weixin":"粮仓金融",
    "website":"app.a16.ink"
}
constant.borrowUnit = function(val){
    return BORROWUNIT[val] || '';
}
// 联系方式
constant.contact = function(name){
    return CONTACT[name] || '';
}
constant.contactAll = function(){
    return CONTACT;
}
module.exports = constant;  
import { loanRecord } from '@api/api_loan';
var productId = "";
var isLoad = false;
var is = false;//
function downloadFile(url1){
    // 下载路径
    
    let fileTransfer = new FileTransfer(),
    uri = encodeURI(url1), 
    fileUrl = cordova.file.externalDataDirectory + uri.substr(uri.lastIndexOf("/") + 1);
        // window.navigator.dialogsPlus.progressStart("下载进度", "0%");
    fileTransfer.download(uri, fileUrl, entry => {
        cordova.plugins.fileOpener2.open(entry.toURL(), 'application/vnd.android.package-archive',{
            error : function(e){
                is = false;
            }, 
            success : function(){
                is = false;
            } 
        });
        console.log("download accessory successful. accessory information : " + JSON.stringify(entry));
    }, error => {
        is = false;
        console.error("download accessory fail. Because of : " + JSON.stringify(error));
    });
    fileTransfer.onprogress = function (e) {
                
        if (e.loaded == e.total) {
            is = false;
            // alert("下载完毕")
        }
    }

    isLoad = true;
    submitRecord(productId,1);
}
function submitRecord(id,type){
    
    loanRecord({
        productId: productId,
        type: type
    }).then(res=>{
        
    });
}
function webwiew(url,name,id){
    productId = id;
    isLoad = false;
    var browser = cordova.ThemeableBrowser.open(url, '_bank', {
        toolbar: {
            height: 40,
            color: '#000000'
        },
        title: {
            color: '#FFFFFF',
            showPageTitle: true,
            staticText: name
        },
        customButtons: [{
            image: 'back',
            imagePressed: 'back_pressed',
            align: 'left',
            event: 'sharePressed'
        }],
        backButtonCanClose: true
    }).addEventListener('loadstart', function (e) {
        var url1 = e.url;
        if(url1.indexOf(".apk")>=0 && !is){
            is = true;
            // browser.close();
            // var b = cordova.ThemeableBrowser.open(url1,'_system');

            var permissions = cordova.plugins.permissions;

            permissions.hasPermission(permissions.READ_EXTERNAL_STORAGE, checkPermissionCallback, null);
            function checkPermissionCallback(status){
                if (!status.hasPermission) {
                    var errorCallback = function() {
                        is = false;
                        downloadFile(url1);
                    }

                    permissions.requestPermission(
                        permissions.READ_EXTERNAL_STORAGE,
                        function(status) {
                            if (status.hasPermission) {
                                errorCallback();
                                
                            } else {
                                downloadFile(url1);
                            }
                        },
                        errorCallback);
                }else{
                    downloadFile(url1);
                }
            }
            
           

        }
    }).addEventListener('sharePressed', function(e) {
        browser.close();
        if(!isLoad){
            submitRecord(productId,2)
        }
    });  
}



export default webwiew;
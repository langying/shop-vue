<template>
	<div id="app" class="f-pr">
		<keep-alive>
			<router-view ></router-view>
		</keep-alive>
		
	</div>
</template>

<script>
	export default {
       
		data() {
			return {
				
			}
		},
		created() {
            // document.title = ""
		},
		methods: {
			
        },
       
	}
</script>

<style lang="scss"  scoped="scoped">

</style>


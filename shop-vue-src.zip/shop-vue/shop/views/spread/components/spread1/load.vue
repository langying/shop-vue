<template>
	<div class="spread">
        <div class="load">
            <div class="logo">
                <img src="../../../../common/assets/images/logo.png" alt="">
                <div>金粮仓</div>
            </div>
            <div>
                <a :href="url" class="load-btn" >下载APP</a>
            </div>
            
        </div>
	</div>
</template>

<script>
    import {Toast,MessageBox} from 'mint-ui';
    
	
	export default {        
		data() {
			return {
                url: ""
			}
		},
		created() {
            var versions = this.globalFun.browserCheck.versions;
            if(versions.ios){
                this.url = "itms-services://?action=download-manifest&url=https://uukd.oss-cn-shanghai.aliyuncs.com/jlc.plist";
            }else{
                this.url = "https://uukd.oss-cn-shanghai.aliyuncs.com/%E9%87%91%E7%B2%AE%E4%BB%93%C2%B7%E6%96%B0%E5%8F%A3%E5%AD%90%E7%A7%92%E5%88%B0%E8%B4%A61.0.2.apk";
            }
		},
		methods: {
         
        }
	}
</script>

<style lang="scss"  scoped="scoped">
@import "../../../../common/styles/mixin.scss";

.load{
    width: 100%;
    height: 100vh;
    text-align: center;
    background: #fff;
    .logo{
        @include font-dpr(18px);
        font-weight: 600;
        color: #999;
        padding: 4rem 0 1.5rem 0;
        img{
            width: 3.2rem;
            height: 3.2rem;
            margin-bottom: 0.3rem;
        }
    }
    .load-btn{
        border: 0;
        width: 3rem;
        height: 1rem;
        line-height: 1rem;
        display: block;
        text-align: center;
        margin: 0 auto;
        background:linear-gradient(to bottom,#99DC1A,#2AB832);
        box-shadow: 0px 2px 5px #999;
        color: #fff;
        border-radius: 6px;
        @include font-dpr(16px);
    }
}
</style>
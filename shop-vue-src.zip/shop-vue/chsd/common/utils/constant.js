var constant = {}
const BORROWUNIT = {"1":"天","2":"月","3":"年"}
const CONTACT = {
    "phone":"181 0266 0616",
    "qq":"2515642113",
    "email":"2515642113@qq.com",
    "weixin":"彩虹速贷",
    "website":"www.chsd.vip"
}
constant.borrowUnit = function(val){
    return BORROWUNIT[val] || '';
}
// 联系方式
constant.contact = function(name){
    return CONTACT[name] || '';
}
constant.contactAll = function(){
    return CONTACT;
}
module.exports = constant;  
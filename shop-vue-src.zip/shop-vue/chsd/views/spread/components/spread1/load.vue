<template>
	<div class="spread">
        <div class="load">
            <div class="logo">
                <img src="../../../../common/assets/images/logo5.png" alt="">
                <div>彩虹速贷</div>
            </div>
            <div>
                <a :href="url" class="load-btn" >下载APP</a>
            </div>
            
        </div>
	</div>
</template>

<script>
    import {Toast,MessageBox} from 'mint-ui';
    
	
	export default {        
		data() {
			return {
                url: ""
			}
		},
		created() {
            var versions = this.globalFun.browserCheck.versions;
            if(versions.ios){
                this.url = "itms-services://?action=download-manifest&url=https://h5.mokalifang.com/load/mobei.plist";
            }else{
                this.url = "http://h5.mokalifang.com/load/mobei.apk";
            }
		},
		methods: {
         
        }
	}
</script>

<style lang="scss"  scoped="scoped">
@import "../../../../common/styles/mixin.scss";

.load{
    width: 100%;
    height: 100vh;
    text-align: center;
    background: #fff;
    .logo{
        @include font-dpr(18px);
        font-weight: 600;
        color: #999;
        padding: 4rem 0 1.5rem 0;
        img{
            width: 3.2rem;
            height: 3.2rem;
            margin-bottom: 0.3rem;
            border-radius: 10px;
        }
    }
    .load-btn{
        border: 0;
        width: 3rem;
        height: 1rem;
        line-height: 1rem;
        display: block;
        text-align: center;
        margin: 0 auto;
        background:linear-gradient(to bottom,#99DC1A,#2AB832);
        box-shadow: 0px 2px 5px #999;
        color: #fff;
        border-radius: 6px;
        @include font-dpr(16px);
    }
}
</style>
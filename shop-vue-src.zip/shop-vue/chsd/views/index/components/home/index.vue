<template >

	<section class="home">

		<pull-to :top-load-method="refresh"  :bottom-load-method="loadmore"  :is-bottom-bounce="isMore">

		<!-- <div class="icon-list row">
			<div class="icon-item col mint-cell" v-for="(item,index) of iconList" :key="index" @click="checkIcon(item)">

				<div class="img"><i :class="item.icon"></i></div>
				<div class="lb">{{item.lb}}</div>
			</div>
		</div> -->

		<!-- <div class="home-block">
			<div class="row row-wrap">
				<div class="item " v-for="(item,index) of recommendList"  :key="index" @click="checkItem(item)">
					<div class="block row mint-cell">
						<span class="mint-cell-mask"></span>
						<div class="img">
							<img :src="item.imgUrl">
						</div>
						<div class="info">
							<div class="name">{{item.name}}</div>
							<div class="lb">{{item.describe}}</div>
						</div>
					</div>
				</div>
			</div>
		</div> -->


		<div class="y-home-head">
			<img class="img" src="./../../../../common/assets/images/home-head-img.png" alt="">
			<div class="title">
				<!-- <span>彩虹速贷</span> -->
			</div>
			<div class="content">
				<div class="box">
					<div class="box-top">
						<div class="box-top-img">
							<img class="imgs" :src="recommendHead.imgUrl" alt="">
						</div>
						<div class="box-top-text">
							<div class="tit"><span>{{recommendHead.name}}</span></div>
							<div class="dir"><span>{{recommendHead.describe}}</span></div>
						</div>
					</div>
					<div class="box-bottom">
						<div class="box-bottom-price">
							<div class="price">{{recommendHead.loanAmountMax}}</div>
							<div class="text">最高可借(元)</div>
						</div>
						<div class="box-bottom-btn">
							<span class="btn" @click.stop="headDetail(recommendHead.productId)">一键拿钱</span>
						</div>
					</div>
				</div>
			</div>
		</div>


		<div class="y-home-block">
			<div class="row row-wrap">
				<div class="y-item" v-for="(item,index) of recommendList"  :key="index" @click="checkItem(item)">
					<div class="block mint-cell">
						<span class="mint-cell-mask"></span>
						<div class="img">
							<img :src="item.imgUrl">
						</div>
						 <div class="info">
							<div class="name">{{item.name}}</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="y-home-tips">据统计，同时申请5家，下款率达99%</div>


		<div class="swipe-wrapper">
			<div class="y-swipe-wrapper">
				<mt-swipe :auto="5000" ref="swipeWrapper">
					<mt-swipe-item class="item" v-for="(item,index) of bannerList" :key="index">
						<a @click="linkUrl(item)">
							<img :src="item.imgUrl">
						</a>
					</mt-swipe-item>
				</mt-swipe>
			</div>
		</div>

		<div class="y-module">
			<div class="title row">
				<span>{{recommendModuleOneName}}</span>
			</div>
			<div class="content">
				<ul class="lst">
					<li v-for="(item,index) of recommendModuleOne" :key="index" @click.stop="headDetail(item.productId)">
						<div class="qs">
							<div class="img">
								<img :src="item.imgUrl" alt="">
								<span class="text">{{item.name}}</span>
							</div>
							<div class="price">最高{{item.loanAmountMax}}</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="y-module">
			<div class="title row">
				<span>{{recommendModuleTwoName}}</span>
			</div>
			<div class="content">
				<ul class="lst">
					<li v-for="(item,index) of recommendModuleTwo" :key="index" @click.stop="headDetail(item.productId)">
						<div class="qs">
							<div class="img">
								<img :src="item.imgUrl" alt="">
								<span class="text">{{item.name}}</span>
							</div>
							<div class="price">最高{{item.loanAmountMax}}</div>
						</div>
					</li>
				</ul>
			</div>
		</div>

		<div class="loan-list y-loan-list">
			<div class="title row">
				<!-- <i class="hot"></i><label>热门极速贷款</label> -->
				<span class="y-loan-row-text">精选贷款</span>
			</div>
			<div class="loan-item mint-cell" v-for="(item,index) of loanList" :key="index" @click.stop="detail(item)">
				<span class="mint-cell-mask"></span>
				<div class="row loan-top">
					<div class="img">
						<img :src="item.imgUrl">
					</div>
					<div class="info col">
						<div class="name">
							<label>{{item.name}}</label>
						</div>
						<div class="tip">{{item.describe || ''}}</div>
						<div class="num">贷款额度<span>{{item.loanAmountMin}}~{{item.loanAmountMax}}元</span></div>
					</div>
					<div class="rate">
						<div class="apply"><label>{{globalFun.numAbbreviate(item.applyTotal,10000)}}</label>人已申请</div>
						<div class="num">{{item.rateScope || 0}}%</div>
						<div class="lb">{{item.rateUnit}}利率</div>
					</div>
				</div>
			</div>
			<div v-if="!isMore && total>0" class="more-end">没有更多数据</div>
		</div>

		</pull-to>


	</section>

</template>

<script>
	import { queryBannerList,queryPromoteList, queryHomeData } from '@api/api_home';
	import { queryLoanList,loanApply } from '@api/api_loan';
	import {Toast,Indicator} from 'mint-ui';
	import PullTo from 'vue-pull-to';
	import webwiew from '../webwiew.js';
	export default {
		data() {
			return {
			   currType: 1,
			   allLoaded:false,
			   bottomStatus:"",
			   topStatus: '',
			   bannerList:[],
			   loanList: [],
			   recommendList:[],
			   iocnList:[],
			   recommendHead:'',
			   recommendModuleOne:[],
			   recommendModuleOneName: '',
			   recommendModuleTwo:[],
			   recommendModuleTwoName: '',
			   searchParmas:{
				   recommendFlag: 1,
				   loanType: 0,
				   hotFlag: 0,
				   page: 1,
				   pageSize: 100
			   },
			   iconList:[{
				   icon:"home-icon1",
				   lb:"0-2千",
				   type: 1
			   },{
				   icon:"home-icon2",
				   lb:"2千-5千",
				   type: 2
			   },{
				   icon:"home-icon3",
				   lb:"5千-1万",
				   type: 3
			   },{
				   icon:"home-icon4",
				   lb:"1万-3万",
				   type: 4
			   },{
				   icon:"home-icon5",
				   lb:"秒批口子",
				   type: 5
			   }],
			   total: 0,
			   count: 0,
			   isMore: true
			}
		},
		components: {
			PullTo
		},
		created() {
			Indicator.open();
			this.getBannerList();
			this.getRecommend();
			this.getLoanList(res=>{
				this.loanList = res.data.list;
				this.close();
			});
			this.getHomeData();
			window.scrollTo(0,0);

		},
		methods: {
			refresh(loaded) {
				this.getBannerList();
				this.getRecommend();
				this.searchParmas.page = 1;
				this.getLoanList(res=>{
					if(res.code == 200){
						this.loanList = res.data.list;
						loaded('done');
					}
				});
				this.getHomeData();

			},
			loadmore(loaded) {
				if(this.total>this.searchParmas.page * this.searchParmas.pageSize){
					this.searchParmas.page += 1;
					this.getLoanList(res=>{
						this.loanList = this.loanList.concat(res.data.list);
						loaded('done');
					})
				}else{
					loaded('done')
					return false;
				}

			},
			close(){
				this.count += 1;
				if(this.count == 2){
					this.count = 0;
					Indicator.close();
				}
			},
			getRecommend(){
				queryPromoteList().then(res=>{
					if(res.code === 200){
						this.recommendList = res.data || [];
					}
				})
			},
			getBannerList(){
				queryBannerList().then(res=>{
					if(res.code === 200){
						this.bannerList = res.data.list;

					}
					this.close();
				})
			},
			getLoanList(callback){
				this.isMore = true;
				queryLoanList(this.searchParmas).then(res=>{
					if(res.code === 200){
						this.total = res.data.total;
						this.isMore = this.total>this.searchParmas.page * this.searchParmas.pageSize;
						if(callback){
							callback(res);
						}
					}
				})
			},
			getHomeData(){
				queryHomeData().then(res=>{
					if(res.code === 200){
						if(res.data){
							let rtop = res.data[0] || '';
							if(rtop){
								this.recommendHead = res.data[0][0];
							}

							if(res.data[1]){
								this.recommendModuleOne = res.data[1];
								this.recommendModuleOneName = res.data.columns[1].name;
							}else{
								this.recommendModuleOne = '';
							}

							if(res.data[2]){
								this.recommendModuleTwo = res.data[2];
								this.recommendModuleTwoName = res.data.columns[2].name;
							}else{
								this.recommendModuleTwo = '';
							}

						}
					}
				})
			},
			linkUrl(item){
				var type = item.type;
				if(type === 1){
					// try{
					// 	console.log(cordova);
					// 	this.$parent.$parent.umengIframe("http://h5.mokalifang.com/#/applyUmeng?name="+item.title+"&type=banner");
					// }catch(e){
					// 	this.$uweb.trackEvent("banner",item.title);
					// }
					this.$uweb.trackEvent("banner",item.title);
					this.$router.push({
						path:"/loanDetail?id="+item.productId,
					})
				}else if(type === 2){
					var url = item.linkUrl;
					try{
                        console.log(cordova);
                        // this.open(url);
                        webwiew(url,item.title,item.productId);
                    }catch(e){
						// location.href = "http://"+window.location.host+"#/apply?id="+item.productId + "&name="+item.title+"&url="+url;
						location.href = url;
					}
					loanApply({
						productId: item.productId
					}).then(res=>{

					})
				}
			},
			checkItem(item){
				switch(item.type){
					case 1:
						this.$router.push({
							path:"/guide",
						})
						break;
					case 2:
						this.$router.push({
							path:"/loanList?columnId="+item.columnId+"&name="+item.name,
						})
						break;
					case 3:
						this.$router.push({
							path:"/loanDetail?id="+item.productId,
						})
						break;
				}

			},
			checkIcon(item){
				var type = item.type;
				if(type == 5){

					this.$router.push({
						path:"/loanList?hotFlag=1&name="+item.lb,
					})
				}else{
					this.$router.push({
						path:"/loanList?loanType="+item.type+"&name="+item.lb,
					})
				}

			},
			headDetail(item){
				this.$router.push({
					path:"/loanDetail?id="+item
				})
			},
			detail(item){
				// try{
				// 	console.log(cordova);
				//  this.$parent.$parent.umengIframe("http://h5.mokalifang.com/#/applyUmeng?name="+item.name+"&type=home");
				// }catch(e){
				// 	this.$uweb.trackEvent("首页", "产品列表",item.name);
				// }
				this.$uweb.trackEvent("首页", "产品列表",item.name);
				this.$router.push({
					path:"/loanDetail?id="+item.productId,
				})
			}
        }
	}
</script>

<style lang="scss"  scoped="scoped">
@import "../../../../common/styles/mixin.scss";
@import './index.less';
@import '../loan/index.less';

</style>

